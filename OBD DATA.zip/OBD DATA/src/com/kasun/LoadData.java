package com.kasun;

public interface LoadData {
}
