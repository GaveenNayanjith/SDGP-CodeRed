package com.kasun;

public interface Load {
    void LoadData();
}
